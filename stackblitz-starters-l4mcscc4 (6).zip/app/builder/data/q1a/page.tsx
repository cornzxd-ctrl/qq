"use client";

export default function Page() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Q1a is WORKING 🎉</h1>
      <p>This step flows correctly.</p>
    </div>
  );
}
