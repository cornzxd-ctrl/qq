"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";

export default function Page() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Q1a is WORKING 🎉</h1>
      <p>This step flows correctly now and uses global styles automanpm install


    </div>
  );
}
